//
//  Trvie2ViewController.swift
//  Examen
//
//  Created by macbook on 5/20/19.
//  Copyright © 2019 nidem. All rights reserved.
//

import UIKit

class Trvie2ViewController: UIViewController {

    var estado = 0;
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var titlestate: UILabel!
    @IBOutlet weak var infoState: UILabel!
    override func viewDidLoad() {
        if(estado == 0){
            self.title = "Trivia Incorrecta"
            self.titlestate.text = "Lastima!"
            self.infoState.text = "Fallaste la trivia, pero no te preocupes, puedes volver a intentarlo!"
        } else{
            self.title = "Trivia Correcta"
            self.titlestate.text = "Felicidades!"
            self.infoState.text = "Contestaste correctamente la trivia, ya puedes obtener tu codigo de promocion!"
        }
        super.viewDidLoad()


        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
