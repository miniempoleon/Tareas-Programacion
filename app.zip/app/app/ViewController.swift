//
//  ViewController.swift
//  app
//
//  Created by MacBook on 3/13/19.
//  Copyright © 2019 DME. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ColorView: UIView!
            @IBOutlet weak var redSwitch: UISwitch!
    
    @IBOutlet weak var greenSwitch: UISwitch!
    @IBOutlet weak var blueSwitch: UISwitch!
    @IBOutlet weak var redSlider: UISlider!
    @IBOutlet weak var greenSlider: UISlider!
    @IBOutlet weak var blueSlider: UISlider!
    
    @IBAction func SwitchChange(_ sender: Any) {
            redSlider.isEnabled = redSwitch.isOn
            blueSlider.isEnabled = blueSwitch.isOn
            greenSlider.isEnabled=greenSwitch.isOn
    }
    @IBAction func SliderChange(_ sender: Any) {
    updateColor()
    }
    @IBAction func btnReset(_ sender: Any) {
        reset()
    }
    func reset(){
        greenSwitch.isOn = false
        redSwitch.isOn = false
        blueSwitch.isOn=false

        updateColor()
        
    }
    func updateColor(){
        var red:CGFloat = 0
        var green:CGFloat = 0;
        var blue:CGFloat = 0;
        if redSwitch.isOn{
            red = CGFloat(redSlider.value)
        }
        if greenSwitch.isOn{
            green = CGFloat(greenSlider.value)
        }
        if blueSwitch.isOn{
            blue = CGFloat(blueSlider.value)
        }
        ColorView.layer.backgroundColor =  UIColor.init(red: red, green: green, blue: blue, alpha: 1).cgColor
    }
    override func viewDidLoad() {

        super.viewDidLoad()
        ColorView.layer.borderWidth = 5
        ColorView.layer.cornerRadius=20
        ColorView.layer.borderColor = UIColor.black.cgColor
        
        // Do any additional setup after loading the view, typically from a nib.
    }


}

