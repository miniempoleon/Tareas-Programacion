//
//  ViewController.swift
//  Rock,Paper,Scissors
//
//  Created by macbook on 3/25/19.
//  Copyright © 2019 Organization. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rock: UIButton!
    @IBOutlet weak var paper: UIButton!
    @IBOutlet weak var scissor: UIButton!
    @IBAction func selectGame(_ sender: Any) {
        let button = sender as? UIButton
        let option = button?.tag
        let enemy = randomSelect()
        var gamestate = 0/// 1 win, 2 loss, 3 empate
        if(button?.tag == enemy){
            gamestate == 3
        } else if(button?.tag == 1){
            if(enemy == 2){
                gamestate = 2
            } else if(enemy == 3){
                gamestate = 1
            }
        } else if(button?.tag == 2){
            if(enemy == 1){
                gamestate = 1
            } else if(enemy == 3){
                gamestate = 2
            }
        } else if(button?.tag == 3){
            if(enemy == 1){
                gamestate = 2
            } else if(enemy == 2){
                gamestate = 1
            }
        }
    }
    func randomSelect()->Int{
        let select = Int.random(in: 1..<3)
        return select
    }
    func getSimbol(_select2:Int)->String{
        let select:Int = _select2
            if(select == 1){
                return "🗿"
            } else if(select == 2){
                return "🧻"
            } else {
                return "✂️"
            }
        }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

